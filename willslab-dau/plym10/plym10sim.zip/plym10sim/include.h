/*
 *  include.h
 *  Global definitions and structure defs for scop2 project.
 */

/******** GLOBAL CONSTANTS *******************/
#define ON           1.0
#define OFF          0.0
#define TRUE         1
#define FALSE        0
#define INIT_BLOCKS  500	/* max # of trial blocks, to init array    */
#define US_BOOST	10.0	/* Amount to increase ß on US-present trials */
/*********************************************/


/******** Hipp Network ***********************/
#define HI          24     /* input units    */
#define HH          12     /* hidden units   */ 
#define HO          26     /* output units   */
#define ALPHA        0.9   /* momentum       */
/* Note: learning rate defined in hipp.c     */
/*********************************************/


/********* Cortical Network *******************/
#define CI         24
#define CH         48
#define CO          2
#define CORT_LR_UP  0.05
#define CORT_LR_DN  0.01 
/*********************************************/


/************* CATEGORY STRUCTURE ********************/
#define N_Training	60 /* half for each category	 */
#define N_Test		10 /* examples per HD			*/
#define N_Testing	130 /* 13 times N_Test is total	*/
#define Replacement	0.1	/* P replacement in training */	
struct trial {
	float input[CI];
	char category;
	int HDfromA;	/* use only for test exemplars  */
	};
/****************************************************/



