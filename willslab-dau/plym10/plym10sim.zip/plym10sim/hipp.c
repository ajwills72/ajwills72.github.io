
/********************************************************
This file contains functions for the hippocampal network.
The following constants must be defined in include.h:
	ALPHA, HI, HH, HO
The network is a three-layer predictive autoencoder trained
	by error backpropagation. There are HI input nodes (same number
	as in cortical net), HH hidden nodes, and HO output nodes
	where HO=HI+2 (the original input plus category).  A
	one-layer vector for each layer stores node activations, two-
	layer vectors store weights between HI and HH nodes and between
	HH and HO nodes, and a one-layer vector for each layer stores
	the biases for nodes in that layer.
The following external function calls may be made to this file:
	(void) init_hipp(char NET)
	float  run_hipp(float input[HI], rerep[HH])
	(void) show_hipp_activ(FILE *fp)
	(void) show_hipp_weights(FILE *fp)
	(void) train_hipp(float class)
	float  hipp_hamming(float inputA[HI], inputB[HI])
This file calls the following external functions:
	float randomweight() -- Init weights -0.3..+0.3
	float f() -- sigmoidal activation function
	float f_deriv() -- derivative of f(), for error backprop
********************************************************/



float HIPP_LR;


/*********************************/
float hippIHweights[HI][HH];
float hippHOweights[HH][HO];
float hippIactiv[HI];
float hippHactiv[HH];
float hippOactiv[HO];
float hippHbias[HH];
float hippObias[HO];
/*********************************/





void init_hipp(NET)
char NET;
{
    float randomweight();
    int x, y;

    if (NET=='i') HIPP_LR=0.05;		/* intact */
    else if (NET=='p') HIPP_LR=2.0;	/* physostigmine */
    else if (NET=='s') HIPP_LR=0.01;	/* scop = .005  */
    for (x=0;x<HI;x++) {
        for (y=0;y<HH;y++) 
            hippIHweights[x][y]=10.0*randomweight();
        hippIactiv[x]=0.0;
        }
    for (x=0;x<HH;x++) {
		for (y=0;y<HO;y++)
			hippHOweights[x][y]=10*randomweight();
        hippHactiv[x]=0.0; 
		hippHbias[x]=10.0*randomweight();
        }
	for (x=0;x<HO;x++) {
		hippOactiv[x]=0.0;
        hippObias[x]=10.0*randomweight();
		}
    }    




float run_hipp(exemplar)
float exemplar[HI];
{
    float net_inp, f();
    int x, y;

    for (x=0;x<HI;x++) hippIactiv[x]=exemplar[x];

    for (x=0;x<HH;x++) {
        net_inp=0.0;
        for (y=0;y<HI;y++)
            net_inp+=hippIHweights[y][x]*hippIactiv[y];
        hippHactiv[x] = f(net_inp+hippHbias[x]);
        }
		
hippHactiv[0]=0.0; 

    for (x=0;x<HO;x++) {
        net_inp=0.0;
        for (y=0;y<HH;y++)
            net_inp+=hippHOweights[y][x]*hippHactiv[y];
        hippOactiv[x] = f(net_inp+hippObias[x]);
        }
		
    return(hippOactiv[HO-1]);
    }    






void show_hipp_activ()
{
    int x;
 
    printf("Hipp Net Activations:\n");
    printf("Iactiv: ");
    for (x=0;x<HI;x++) printf(" %4.2f ", hippIactiv[x]);
    printf("\nHactiv: ");
    for (x=0;x<HH;x++) printf(" %4.2f ", hippHactiv[x]);
    printf("\nOactiv: ");
    for (x=0;x<HO;x++) printf(" %4.2f ", hippOactiv[x]);
    printf("\n");
    }





void show_hipp_weights(fp)
FILE *fp;
{
    int x, y;
 
    /* note: print only to file, not to screen! */
    fprintf(fp, "Hipp Network Weights:\n");
    for (x=0;x<HH;x++) {
        fprintf(fp, "To hidden unit %d: ", x);
        for (y=0;y<HI;y++)
            fprintf(fp, "%d:%4.2f\t", y, hippIHweights[y][x]);
        fprintf(fp, "(T=%4.2f)", hippHbias[x]);
        fprintf(fp, "\n");
        }
    for (y=0;y<HO;y++) {
        fprintf(fp, "To output unit %d: ", y);
        for (x=0;x<HH;x++)
            fprintf(fp, "%d:%4.2f\t", x, hippHOweights[x][y]);
        fprintf(fp, "(T=%4.2f)\n", hippObias[y]);
        }
    fprintf(fp, "\n");
    }
	
	
float show_hipp_op()
{
	int x;
	
	printf("hipp,");
	for (x=HO-CO;x<HO;x++) printf("%4.2f,", hippOactiv[x]);
	return(hippOactiv[HO-CO]);
	}



void train_hipp(category)
char category;
{
    static float lastHOdel[HH][HO], lastIHdel[HI][HH];
    static float lastObiasdel[HO], lastHbiasdel[HH];
    float err[HO], class[2], backerr, delta, f_deriv();
    int x, y, z;
    float BETA;
	
   BETA=/*US_BOOST*/HIPP_LR; 
   class[0]=0.0; class[1]=0.0;
   if (category=='A') class[0]=1.0; 
   if (category=='B') class[1]=1.0; 

    for (x=0;x<HO;x++) {
        if (x<HI)
            err[x] = (hippIactiv[x]-hippOactiv[x])*f_deriv(hippOactiv[x]);
        else if (x==HI) err[x] = (class[0]-hippOactiv[x])*f_deriv(hippOactiv[x]);
		else err[x]=(class[1]-hippOactiv[x])*f_deriv(hippOactiv[x]);
        for (y=0;y<HH;y++) {
            delta = BETA * err[x] * hippHactiv[y] + ALPHA * lastHOdel[y][x];
		     hippHOweights[y][x] += delta;
		      lastHOdel[y][x] = delta;
            }
        delta = BETA * err[x] * 1.0 + ALPHA * lastObiasdel[x];
   		hippObias[x] += delta;
	      lastObiasdel[x] = delta;
        }

    for (y=0;y<HH;y++) {
        backerr=0.0;
        for (x=0;x<HO;x++)
            backerr += err[x] * hippHOweights[y][x];
        backerr *= f_deriv(hippHactiv[y]);
        for (z=0;z<HI;z++) {
            delta = BETA * backerr * hippIactiv[z] + ALPHA * lastIHdel[z][y];
     		hippIHweights[z][y] += delta;
		       lastIHdel[z][y] = delta;
            }
        delta = BETA * backerr * 1.0 + ALPHA * lastHbiasdel[y];
		hippHbias[y] += delta;
  		lastHbiasdel[y] = delta;
        }
    }




float hipp_hamming(inputA, inputB)
float inputA[HI], inputB[HI];
{
	int x;
	float h, rerepA[HH], rerepB[HH];
	float f_abs();

	run_hipp(inputA, rerepA);
	run_hipp(inputB, rerepB);
	for (x=0,h=0.0;x<HH;x++) h+=f_abs(rerepA[x]-rerepB[x]);
	return(h);
	}


