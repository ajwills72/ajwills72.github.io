# DAU: PLYM10
# 08-10-2015
# Written by: Cath Myers (nearly all the C code)
# and Andy Wills (all the R code).

# This R script compiles C source code and the
# calls the resulting object code with a system() call.

rm(list=ls())
# Compile C code
system('gcc -o corhip main.c -lm')
# Load custom plots
source('plotfunc.R')

bigdta <- NULL
# Multiple runs of model
mod.type <- 'l'
for(run in 1:2000) {
  if(mod.type == 'i') mod.type <- 'l' else mod.type <- 'i'
  # Run it and output to file
  syscall <- paste0('./corhip ',mod.type,' ',round(runif(1)*1e6,0),' > results.txt')
  system(syscall)
  # Read in that file
  dta <- read.table('results.txt',sep = ",",skip=1,stringsAsFactors=FALSE)
  bigdta <- rbind(bigdta,cbind(run,dta,mod.type))  
}


# Process it
bigdta <- bigdta[,c(1,2,3,5,7,8,10,11,13)]
colnames(bigdta) <- 
  c('run','phase','trial','stim','hipp1','hipp2','cort1','cort2','mod.type')
testdta <- bigdta[bigdta$phase=='test',]
testdta$stim <- as.numeric(testdta$stim)
# Save out
save(bigdta,file='2000runs.RData')

# Decision rule
k <- 3
testdta$pa <- 
  exp(k * testdta$cort1) / (exp(k* testdta$cort1) + exp(k*testdta$cort2))

# Aggregate a summary
testsum <- aggregate(testdta$pa,list(testdta$mod.type,testdta$stim),mean)
colnames(testsum) <- c('mdl','dist','pa') 
genplot(testsum)

# Produce a graph in same format as empirical analysis
testsum$pc <- testsum$pa

testsum$pc[testsum$dist >6] <- 1 - testsum$pc[testsum$dist >6] 

testsum$distbin <- 3

testsum$distbin[
  testsum$dist == 0 | testsum$dist == 12
  ] <- 0

testsum$distbin[
  testsum$dist < 12 & testsum$dist > 8
  ] <- 1

testsum$distbin[
  testsum$dist > 0 & testsum$dist < 4
  ] <- 1

testsum$distbin[
  testsum$dist < 9 & testsum$dist > 6
  ] <- 2

testsum$distbin[
  testsum$dist > 3 & testsum$dist < 6
  ] <- 2

# Aggregate a binned summary
binsum <- aggregate(testsum$pc,list(testsum$mdl,testsum$distbin),mean)
colnames(binsum) <- c('mdl','dist','pc') 
print(binsum)

pdf(file='binsum.pdf'
    , width= 3
    , height = 3
    , pointsize = 9
    , title = '')
binplot(binsum)
dev.off()



