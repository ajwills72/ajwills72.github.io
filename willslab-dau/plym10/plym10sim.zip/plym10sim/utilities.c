/*********************************/
/* This file contains some basic
/* utility functions related to
/* random numbers and EBP procedure:
/*
/* float randomweight()
/* float randomfrac()
/* int randomint()
/* float f()
/* float f_deriv()
/* float f_abs()
/***********************************/

/* The usual sigmoidal activation function. */
/* X is the weighted sum of node input.     */
/* x= +inf ... -inf, f(x)= 0.0 ... 1.0      */
float f(x) 
float x;
{
//	extern double exp();
	double E;
	float F;

    E=exp(0.0-x);
    F=(float)E;
    return(1.0/(1.0+F));
    }

/* The derivative of the above function.    */
/* X should be node output, returns 0..1.   */
float f_deriv(x) /* FIRST DERIVATIVE OF ACTIVATION FUNCTION */
float x;
{
    return(x*(1.0-x));
    }
	
/*********************************************
TRAINING RULES:                         

for an output node x:
    dx(t) = (tx-yx) * f_deriv( net-input-to-x )
          = (tx-yx) * yx * (1-yx)
  Dwjx(t) = BETA * dx(t) * yj + ALPHA * Dwjx(t-1)
where j is a hidden node outputting to x and
BETA is the learning rate and ALPHA is momentum.
Do this also for x's threshold weight.

for a hidden node j:
    dj(t) = yj * (1-yj) * E(over x){ dx(t) * wjx }
  Dwij(t) = BETA * dj(t) * yi + ALPHA * Dwij(t-1)
where i is a node outputting to j and x is a node
to which j outputs and BETA and ALPHA are learning
rate and momentum.  Do this also for j's threshold.
**********************************************/

    	

/* Initialises weights in the range -0.3 ... 0.3 */
float randomweight()
{
    float x;
	float randomfrac();

    do x=(randomfrac()*0.6)-0.3;
    while (x==0);
    return(x);
    }
	
	
	
/** RANDOMFRAC: random float in range [0,1.0) ***/
float randomfrac()
{
	extern long random();
	long R;
	float F;
	
	R=random();
	F=(float)R;
	return( ((((F*1.0)/1024.0)/1024.0)/2048.0) );
    }
	
	
	
/* F_ABS: Return absolute value of a float */
float f_abs(x)
float x;
{
     if (x<0.0) return(0.0-x);
     else return(x);
     }
	

/* RANDOMINT: Return a random integer in the range Low...High (inclusive) */
int randomint(Low, High)
int Low, High;
{
	extern long random();
	long R;
	int I;
	
	R=random();
	I=(int)R;
	return( (I%(High-Low+1))+Low );
	}
	
	
/* SEED_RANDOMS: Call at start of program to seed random number generator */
int seed_randoms()
{
	srandom( time (NULL) );
	return(TRUE);
	}
	
/* GEN_RANDOMS: For an array of specified size N, fill with integers
0..N-1 in shuffled order. */
int gen_randoms(arr, arr_size)
int arr[], arr_size;
{
	int x, y, temp, randomint();
	
	for (x=0;x<arr_size;x++) arr[x]=x;
	for (x=0;x<arr_size;x++) {
		y=randomint(0,arr_size-1);
		temp=arr[x];
		arr[x]=arr[y];
		arr[y]=temp;
		}
	return(arr_size);
	}
	
