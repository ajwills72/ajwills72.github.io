//
//  main.m
//  scop07_squiggle4
//
//  Created by Catherine Myers on 2/28/09.
//
//  Ported from Objective C for Xcode to vanilla C for gcc.
//  by Andy Wills 2015-07-29
//
//  Command to compile: gcc -o corhip main.c -lm

#include <stdio.h>
#include <math.h>
#include "include.h"
#include "cort.c"
#include "hipp.c"
#include "run.c"
#include "utilities.c"

/******* MAIN ******************************************************************/
/** This is a variation on the standard net, used in the scop07 series of 
/** programs, but with task changed to "Squiggle" (Wills & McLaren 1997 
/** polymorphic category learning and generalization gradient experiment).  
/*******************************************************************************/

struct trial trainpat[N_Training];
struct trial testpat[N_Testing];


int main(int argc, char *argv[])
{
	char NET[5];
	FILE *fp, *fopen();
	int trial, do_problem(), shutdown();
  	void init_cort(), init_hipp(), init_task(), init_nets();

  // (void) seed_randoms();
   
  srandom( strtol(argv[2],NULL,0) );
   
	NET[0] = (char)argv[1][0];
  // printf("NET type (i=intact, l=lesion, s=scop, p=phys)? "); scanf("%s", &NET); 
	if ((NET[0]!='i')&&(NET[0]!='l')&&(NET[0]!='s')&&(NET[0]!='p')) NET[0]='i';
	printf("Network type: %c\n",NET[0]); 
	fp=fopen("test", "w");
	
	init_cort();
	if (NET[0]!='l') init_hipp(NET[0]);
	init_task();
	init_nets(NET[0]);

	for (trial=0;trial<N_Training;trial++) {
		learn(NET[0], trainpat[trial]);
		printf("train,%d,cat,%c,", trial, trainpat[trial].category);
		show_hipp_op(); (void) show_cort_op(); printf("\n");
		}
	for (trial=0;trial<N_Testing;trial++) {
		test(NET[0], testpat[trial]);
		printf("test,%d,HDfromA,%d,", trial, testpat[trial].HDfromA);
		show_hipp_op(); (void) show_cort_op(); printf("\n");
		}

	(void) shutdown(fp);
	return(TRUE);
	}
	

/*****InitTask*******************************************************************/
/** NB human version picks 12 of 36 squiggles for A and 12 for B per subject;
/** here, just use inputs 0..11 for A and 12..23 for B (don't bother shuffling).
/** (1) For training, construct N_Training exemplars of each class by shuffling
/** the prototype, then 10% prob of replacing each element with a random from other
/** category (without duplication).
/** (2) For testing, construct N_Test exemplars at HD=0..12 from A prototype.
/********************************************************************************/
void init_task()
{
    int x, y, z, new, myB, NinClass, Nelements, arr[N_Training], AtoSwap[CI], BtoUse[CI];
	extern struct trial trainpat[N_Training], testpat[N_Testing];
	extern int gen_randoms();
 
	/* Form training exemplars */
	
	/* generate random trial order */
	(void) gen_randoms(arr, N_Training);
	/* Construct N_Training/2 exemplars of each class */
	NinClass=N_Training/2;
	Nelements=CI/2;
	for (x=0;x<NinClass;x++) {
		for (y=0;y<Nelements;y++) { trainpat[arr[x]].input[y]=1.0; trainpat[arr[x]].input[y+Nelements]=0.0; }
		trainpat[arr[x]].category='A';
		for (y=0;y<Nelements;y++) 
			if (randomint(1,10)==10) { /* replace that element with one from B */
				new=randomint(Nelements, CI-1);
				while (trainpat[arr[x]].input[new]>0.5) new=randomint(Nelements, CI-1);
				trainpat[arr[x]].input[y]=0.0;
				trainpat[arr[x]].input[new]=1.0;
				}
		}
	for (x=NinClass;x<N_Training;x++) {
		for (y=0;y<Nelements;y++) { trainpat[arr[x]].input[y]=0.0; trainpat[arr[x]].input[y+Nelements]=1.0; }
		trainpat[arr[x]].category='B';
		for (y=Nelements;y<CI;y++) 
			if (randomint(1,10)==10) { /* replace that element with one from A */
				new=randomint(0, Nelements-1);
				while (trainpat[arr[x]].input[new]>0.5) new=randomint(0, Nelements-1);
				trainpat[arr[x]].input[y]=0.0;
				trainpat[arr[x]].input[new]=1.0;
				}
		}

/* for (x=0;x<N_Training;x++) {
	printf("pat %d class %c: ", x, trainpat[x].category);
	for (y=0;y<CI;y++) printf("%4.2f ", trainpat[x].input[y]);
	printf("\n");
	}
	*/
	
	/* Form 130 training exemplars; NB don't need to shuffle as nets don't train on test trials */
	new=0;
	for (x=0;x<13;x++) { /* for each possible HD from A */
		for (y=0;y<N_Test;y++) { /* for each repetition at that HD */
			testpat[new].HDfromA=x;
			for (z=0;z<Nelements;z++) { testpat[new].input[z]=1.0; testpat[new].input[z+Nelements]=0.0; }
			gen_randoms(AtoSwap, Nelements);
			gen_randoms(BtoUse, Nelements);
			for (z=0;z<testpat[new].HDfromA;z++) {
				testpat[new].input[AtoSwap[z]]=0.0;
				myB=BtoUse[z]+Nelements;
				testpat[new].input[myB]=1.0;
				}
			new++;
			}
		}
		
/* for (x=0;x<N_Testing;x++) {
	printf("pat %d HD %d: ", x, testpat[x].HDfromA);
	for (y=0;y<CI;y++) printf("%4.2f ", testpat[x].input[y]);
	printf("\n");
	}
	*/
		
	}



/****Shutdown***************************************************************/
/** Just save the cort net weights to a file and close the output file.   **/
/***************************************************************************/
int shutdown(fp)
FILE *fp;
{
	void show_cort_weights(), show_hipp_weights();
	
	show_cort_weights(fp); 
	show_hipp_weights(fp);
	fclose(fp);
	return(TRUE);
	}



