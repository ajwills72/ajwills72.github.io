/**
 *  run.c
 *  scop07
 *
 *  Created by Cath Myers on 9/6/07.
 *
 **/


void init_nets(NET)
char NET;
{
   int x;
   struct trial dummy;
   float learn();

   for (x=0;x<CI;x++) dummy.input[x]=0.0;
   dummy.category='0';

//   printf("Initializing nets ...\n");
   for (x=0;x<INIT_BLOCKS;x++)
	learn(NET, dummy);
   }
 


float learn(NET, pattern)
char NET;
struct trial pattern;
{
    float CR, run_cort();
	
	if (NET!='l') run_hipp(pattern.input); 
	/* show_hipp_activ();  */
    CR=run_cort(pattern.input); 
	/* show_cort_activ(); */
    train_cort(pattern.category, NET); 
    if (NET!='l') train_hipp(pattern.category);
    return(CR);
    }


float test(NET, pattern)
char NET;
struct trial pattern;
{
	float CR, run_cort();
	
	if (NET!='l') run_hipp(pattern.input);
	CR=run_cort(pattern.input);
	return(CR);
	}
