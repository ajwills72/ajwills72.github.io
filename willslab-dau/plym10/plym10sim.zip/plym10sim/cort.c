/********************************************************
This file contains functions for the cortical network.
The following constants must be defined in include.h:
	CI, CH, CO, CORT_LR_UP, CORT_LR_DN
The network is defined as a three-layer network, with CI
	input layer nodes, CH hidden layer nodes, and CO output
	layer nodes.  There is one vector storing current activations
	for the nodes in each layer, and 2D vectors storing current
	weights between IH and between HO layers.  There is also a
	set of 1D vectors (one per layer) storing the current bias weights
	node in that layer.
The following external function calls may be made to this file:
	(void) init_cort()
	float  run_cort(input[CI])
	(void) show_cort_activ(FILE *fp)
	(void) show_cort_weights(FILE *fp)
	(void) train_cort(float class, t[HH]; char AE_ROLE)
	float  cort_hamming(float inputA[CI], inputB[CI])
The following external function calls are made FROM this file:
	float randomweight() -- generate # in range -0.3...+0.3
	float f() -- the sigmoidal activation function
********************************************************/

/*********************************/
float cortIHweights[CI][CH];
float cortHOweights[CH][CO];
float cortIactiv[CI];
float cortHactiv[CH];
float cortOactiv[CO];
float cortHbias[CH];
float cortObias[CO];
/*********************************/

/*********************************/
float HIPPtoCORTweights[HH][CH];
/*********************************/



void init_cort(NET)
{
    float randomweight(), randomfrac();
    int x, y;
	
    for (x=0;x<CI;x++) {
        for (y=0;y<CH;y++)
            cortIHweights[x][y]=10.0*randomweight();
        cortIactiv[x]=0.0;
        }
    for (x=0;x<CH;x++) {
        for (y=0;y<CO;y++)
            cortHOweights[x][y]=10.0*randomweight();
        cortHactiv[x]=0.0;
        cortHbias[x]=10.0*randomweight();
        }
    for (y=0;y<CO;y++) {
        cortOactiv[y]=0.0;
        cortObias[y]=10.0*randomweight();
        }
    /* one-to-many mapping from hipp hidden to cort hidden layer */
    if (NET!='l')
		for (y=0;y<CH;y++) {
			for (x=0;x<HH;x++)
				HIPPtoCORTweights[x][y]=0.0;
			HIPPtoCORTweights[y%HH][y]=1.0;
			}
    }






float run_cort(input)
float input[CI];
{
    float net_inp, f();
	float dummy;
    int x, y;

    for (x=0;x<CI;x++) cortIactiv[x]=input[x];

	dummy=f(0.0); /* just clear out the f() function first time through... */
    for (x=0;x<CH;x++) {
        net_inp=0.0;
        for (y=0;y<CI;y++)
            net_inp+=cortIHweights[y][x]*cortIactiv[y];
        cortHactiv[x]=f(net_inp+cortHbias[x]);
        }
    for (x=0;x<CO;x++) {
        net_inp=0.0;
        for (y=0;y<CH;y++)
            net_inp+=cortHOweights[y][x]*cortHactiv[y];
        cortOactiv[x] = f(net_inp+cortObias[x]);
        }

    return(cortOactiv[0]);
    }





void show_cort_activ()
{
    int x;

    printf("\tCORT activs: ");
    for (x=0;x<CI;x++) printf("I:%4.2f, ", cortIactiv[x]);
    printf("\n");
    for (x=0;x<CH;x++) printf("H:%4.2f, ", cortHactiv[x]);
    printf("\n");
    for (x=0;x<CO;x++) printf("O:%4.2f\n", cortOactiv[x]);
    printf("\n");
    }


float show_cort_op()
{
	int x;
	
	printf("cort,");
	for (x=0;x<CO;x++) printf("%4.2f,", cortOactiv[x]);
	return(cortOactiv[0]);
	}


void show_cort_weights(fp)
FILE *fp;
{
    int x, y;

    /* note: print to file only, not screen! */
    fprintf(fp, "Cort WEIGHTS:\n");
    for (x=0;x<CH;x++) {
        fprintf(fp, "To hidden unit %d: ", x);
        for (y=0;y<CI;y++)
            fprintf(fp, "%d:%4.2f\t", y, cortIHweights[y][x]);
        fprintf(fp, "(T=%4.2f)", cortHbias[x]);
		fprintf(fp, "\n from hipp: ");
		for (y=0;y<HH;y++) fprintf(fp, "%4.2f ", HIPPtoCORTweights[y][x]);
        fprintf(fp, "\n");
        }
    fprintf(fp, "To output unit: ");
    for (x=0;x<CO;x++) {
        fprintf(fp, "O%d:  ", x);
        for (y=0;y<CH;y++)
            fprintf(fp, "%d:%4.2f\t", y, cortHOweights[y][x]);
		fprintf(fp, "(T=%4.2f)\n", cortObias[x]);
        }
	fprintf(fp, "\n");
    }


void train_cort(category, AE_ROLE)
char category;
char AE_ROLE;
{
    int x, y;
    float err, class[HO], BETA_UP, BETA_DN;
	extern float hippHactiv[HH];
	
	BETA_UP=US_BOOST*CORT_LR_UP; 
	BETA_DN=US_BOOST*CORT_LR_DN; 
	class[0]=0.0; class[1]=0.0;
	if (category=='A') class[0]=1.0;
	if (category=='B') class[1]=1.0;
          
    /* NOTE ONLY LMS THROUGH H-O CONNECTIONS! */
    for (x=0;x<CO;x++) {
           err = (class[x] - cortOactiv[x]);
           for (y=0;y<CH;y++)
               cortHOweights[y][x] += BETA_UP * err * cortHactiv[y];
           cortObias[x] += BETA_UP * err * 1.0;
           }

    if (AE_ROLE=='l') return; 

    for (x=0;x<CH;x++) {
        err= 0.0 - cortHactiv[x];
        for (y=0;y<HH;y++) err += hippHactiv[y] * HIPPtoCORTweights[y][x];
		for (y=0;y<CI;y++) cortIHweights[y][x] += BETA_DN * err * cortIactiv[y];
        cortHbias[x] += BETA_DN * err * 1.0;
       }
    }



float cort_hamming(inputA, inputB)
float inputA[CI], inputB[CI];
{
	int x;
	float h, temp[CH], f_abs(), run_cort();
	
	h=run_cort(inputA);
	for (x=0;x<CH;x++) temp[x]=cortHactiv[x];
	h=run_cort(inputB);
	for (x=0,h=0.0;x<CH;x++) h+=f_abs(temp[x]-cortHactiv[x]);
	return(h);
	}
